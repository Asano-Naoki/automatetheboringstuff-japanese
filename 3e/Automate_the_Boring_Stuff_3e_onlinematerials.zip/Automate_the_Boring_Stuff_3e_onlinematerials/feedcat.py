print('''Dear Alice,

Can you feed Eve's cat this weekend?

Sincerely,
Bob''')